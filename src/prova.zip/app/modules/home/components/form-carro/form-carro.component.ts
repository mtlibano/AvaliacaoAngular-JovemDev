import { Component, OnInit } from '@angular/core';
import { Carro } from '../../models/carro';
import { CarroServiceService } from '../../services/carro.service.service';

@Component({
  selector: 'app-form-carro',
  templateUrl: './form-carro.component.html',
  styleUrls: ['./form-carro.component.scss']
})
export class FormCarroComponent implements OnInit {

  carroSelected: Carro = {
    marca: '',
    placa: '',
    ano: 0,
    tipo: '',
  };

  constructor(private service: CarroServiceService) {}

  public addCarroForm(
    marca: string,
    placa: string,
    ano: string,
    tipo: string
  ) {
    return this.service.addCarro(marca, placa, parseInt(ano), tipo);
  }

  ngOnInit(): void {
    this.service.emitCarro.subscribe((carro: Carro) => {
      this.carroSelected = carro;
    });
  }

}
