import { Component, OnInit } from '@angular/core';
import { Carro } from '../../models/carro';
import { CarroServiceService } from '../../services/carro.service.service';

@Component({
  selector: 'app-read-carro',
  templateUrl: './read-carro.component.html',
  styleUrls: ['./read-carro.component.scss']
})
export class ReadCarroComponent implements OnInit {

  list: Carro[] = [];
  pop: boolean = false;
  lux: boolean = false;
  car: boolean = false;

  constructor(private service: CarroServiceService) {}

  ngOnInit(): void {
    this.list = this.service.getListAll();
    this.selectClass();
  }

  deleteCarro(index: number) {
    this.service.removeCarro(index);
  }

  selectCarro(index: number) {
    this.service.getCarro(index);
  }

  selectClass() {
    for (let i = 0; i < this.list.length; i++) {
      if (this.list[i].tipo == "Popular") {
        this.pop = true;
        this.lux = false;
        this.car = false;
      }
      else if (this.list[i].tipo == "Luxo") {
        this.lux = true;
        this.pop = false;
        this.car = false;
      }
      else if (this.list[i].tipo == "Carga") {
        this.car = true;
        this.pop = false;
        this.lux = false;
      }
    }
  }

}
