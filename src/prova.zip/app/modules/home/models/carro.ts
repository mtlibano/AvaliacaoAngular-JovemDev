export interface Carro {
    marca: string;
    placa: string;
    ano: number;
    tipo: string;
  }