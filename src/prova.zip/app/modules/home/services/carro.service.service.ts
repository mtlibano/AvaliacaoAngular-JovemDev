import { EventEmitter, Injectable } from '@angular/core';
import { Carro } from '../models/carro';

@Injectable({
  providedIn: 'root'
})
export class CarroServiceService {

  public emitEvent = new EventEmitter();
  public emitCarro = new EventEmitter();

  carroSelected: Carro = {
    marca: '',
    placa: '',
    ano: 0,
    tipo: '',
  };

  constructor() { }  

  carros: Carro[] = [
    {
      marca: 'Max',
      placa: 'MKF4902',
      ano: 2010,
      tipo: 'Popular',
    },
    {
      marca: 'Niki',
      placa: 'MKG1221',
      ano: 2020,
      tipo:'Luxo',
    },
  ];

  public addCarro(
    marca: string,
    placa: string,
    ano: number,
    tipo: string
  ) {
    this.carros.push({
      marca: marca,
      placa: placa,
      ano: ano,
      tipo: tipo,
    });
    this.emitEvent.emit(this.carros.length);
    return this.carros;
  }

  public getListAll() {
    return this.carros;
  }

  public removeCarro(index: number) {
    return this.carros.splice(index, 1);
  }

  public getCarro(index: number) {
    this.carroSelected = this.carros[index];
    this.emitCarro.emit(this.carroSelected);
  }

}